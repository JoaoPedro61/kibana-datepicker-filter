export { Component as VisComponent } from './component';
