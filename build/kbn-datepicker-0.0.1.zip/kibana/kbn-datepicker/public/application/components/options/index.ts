export { Component as OptionsComponent } from './component';
